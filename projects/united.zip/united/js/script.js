$(document).ready(function(){
    $('nav>ul.gnb>li').hover(function(){
        $(this).find('ul.sub').stop().slideDown();
    }, function(){
        $(this).find('ul.sub').stop().slideUp();
    });
    
    $('.join>ul>li').eq(0).click(function() {
        $(".modal").show();
    });
    $(".inner_modal>button").click(function(){
        $(".modal").hide();
    });
});