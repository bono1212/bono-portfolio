var age=20;

document.write("당신의 나이는 "+age+"살입니다")